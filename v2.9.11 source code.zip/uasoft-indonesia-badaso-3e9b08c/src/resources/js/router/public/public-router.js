export default [
  // your public route here
  // example
  //   {
  //     path: "PageUrl",
  //     name: "PageName",
  //     component: PageComponent,
  //   },
];

Route in other directory in route directory is for using in layout that badaso provide.
You can add your router here if you want to make a new layout

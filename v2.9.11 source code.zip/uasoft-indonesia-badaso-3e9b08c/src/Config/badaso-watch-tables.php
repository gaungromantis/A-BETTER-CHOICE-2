<?php

return [
    // table names for generating CRUD_DATA seeders.
];

<?php

return [
    'priority' => 'high',
    // priority send firebase
    'tell_role_names' => ['administrator', 'customer'],
    // array role name
];

<?php

namespace Uasoft\Badaso\Models;

use Illuminate\Database\Eloquent\Model;

class Migration extends Model
{
    protected $guarded = [];
}
